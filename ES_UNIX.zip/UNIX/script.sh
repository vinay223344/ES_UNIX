cd /home
