#! /usr/bin/home -f

if ($#argv < 2 ) then
    echo "provide required no of arguments"
else
   if (-e $argv[1] ) then
      echo "$argv[1] is present"
   else
      echo "$argv[1] is not present"
      exit
   endif
   if (-e $argv[2]) then
     echo "Data base $argv[1] already exists. Do you want to over-write ? Press y/n"
     set userPerm = $<
     if ($userPerm == "y") then
         echo ""
     else if($userperm == "n") then
          exit
     else
         rm -r $argv[2]
         mkdir database_new
    endif
     
         
   
