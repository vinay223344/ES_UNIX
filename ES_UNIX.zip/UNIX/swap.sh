#!/usr/bin/csh
set list = (hi hello sai madam how where who paper rock focus doing you)
   #set list[5] = "fine"
#echo $list
set swap = 1
foreach word($list)
 if ($word == how) then
  echo "matched"
   set list[$swap] = fine
 else
  echo "unmatched"
@ swap++
endif
end
echo "$list"
