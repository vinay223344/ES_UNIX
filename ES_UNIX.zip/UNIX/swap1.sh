#!/usr/bin/csh -f
#set file = `cat  $argv`
#echo $file
pwd
set lines = `wc -l   $argv[1]`
echo $lines
set currentLine = 1
while ($currentLine <= $lines[1])
set lines1 = `tail -n +$currentLine $argv[1] | head -1`
echo $lines1
set swap = 1
foreach word ($lines1)
  if ($word ==  slvtpfet)then
      set lines1[$swap] = slvtpfet

  endif 
@ swap++
end
 @ currentLine = $currentLine + 1
echo "$lines1"  >> $argv[2] 
end
#echo $words
#echo $lines1
#echo $lines
#echo $lines1
#set words = `wc -w  $lines1`
#echo $lines1[2]

