import random
import os
import pwd
import grp
import shutil

# Custom shuffle function to ensure no element remains in its original position
def custom_shuffle(lst):
    shuffled_list = lst.copy()
    while True:
        random.shuffle(shuffled_list)
        if not any(shuffled_list[i] == lst[i] for i in range(len(lst))):
            break
    return shuffled_list

# Read and process the mapping file
with open('MapFile_AD03.txt', 'r') as f: 
    lines = f.readlines() 
    data = {} 
    for line in lines: 
        key, value = line.strip().split('\t') 
        data[key] = value 

# Remove the header entry
data.pop('PermanentUserID')

# Shuffle IDs and directories
keys_ID = list(data.keys())
values_dir = list(data.values())
shuffle_ID = custom_shuffle(keys_ID)
shuffle_dir = custom_shuffle(values_dir)

# Write the shuffled mapping to a new file
with open('eval_mapFile.csh', 'w') as f:
    f.write("PermanentUserID\tTemporaryUserID\tEvaluationDir\tEvaluatedByUserID\n")
    for i in range(len(data)):
        f.write(f"{keys_ID[i]}\t{values_dir[i]}\t\t{shuffle_dir[i]}\t\t{shuffle_ID[i]}\n")

# Custom function to copy directory while ignoring symlinks & errors
def copy_dir_safe(src, dst):
    """Copies a directory, skipping symlinks and ignoring errors."""
    for item in os.listdir(src):
        src_item = os.path.join(src, item)
        dst_item = os.path.join(dst, item)

        # Skip symlinks
        if os.path.islink(src_item):
            print(f"?? Skipping symlink: {src_item}")
            continue

        # Copy file
        if os.path.isfile(src_item):
            os.makedirs(os.path.dirname(dst_item), exist_ok=True)
            shutil.copy2(src_item, dst_item)

        # Copy directory
        elif os.path.isdir(src_item):
            os.makedirs(dst_item, exist_ok=True)  # Ensure directory exists
            copy_dir_safe(src_item, dst_item)  # Recursively copy

# Copy directories and files correctly
for i in range(len(data)):
    src_path = f"/home/VLSI/missad03/USERS/admentor/EXAM/Eval/UNIX/{values_dir[i]}"
    dst_path = f"/home/VLSI/missad03/EXAMS/Evaluation_UNIX/{shuffle_dir[i]}"

    # Debugging: Print paths being processed
    print(f"Processing:\n  Source: {src_path}\n  Destination: {dst_path}")

    # Check if source exists before copying
    if not os.path.exists(src_path):
        print(f"? Error: Source '{src_path}' does not exist. Skipping this entry.")
        continue

    # Skip symbolic links at root level
    if os.path.islink(src_path):
        print(f"?? Skipping symbolic link: {src_path}")
        continue

    # If the destination already exists, remove it
    if os.path.exists(dst_path):
        shutil.rmtree(dst_path)

    # Create destination directory
    os.makedirs(dst_path, exist_ok=True)

    # Copy directory safely
    copy_dir_safe(src_path, dst_path)

    # Set permissions: Allow owner and group full access
    os.chmod(dst_path, 0o770)  # Read/write/execute for owner and group, no access for others

    # If the user is part of "missad03" group, change only the group ownership
    try:
        current_gid = os.getgid()
        if current_gid == grp.getgrnam("missad03").gr_gid:
            os.chown(dst_path, -1, current_gid)  # Change only group if allowed
    except KeyError:
        print(f"?? Warning: Group 'missad03' does not exist on this system.")

print("? Directories and files copied successfully! Symlinks and missing files were skipped.")

